<div class="e-content">
    @php(the_content())
</div>
