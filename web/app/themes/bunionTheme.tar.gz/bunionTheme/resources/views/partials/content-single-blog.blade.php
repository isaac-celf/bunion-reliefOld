<div class="e-content">
    <div class="blog-content">
        @php(the_content())
    </div>
</div>
