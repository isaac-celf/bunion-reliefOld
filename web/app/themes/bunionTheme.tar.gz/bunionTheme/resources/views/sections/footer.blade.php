<footer class="content-info alignfull mb-0 mt-0 container p-md-5 px-3">
    @include('partials.footer')
</footer>
