<footer class="content-info alignfull mb-0 mt-0 container p-md-5">
    @include('partials.footer')
</footer>
