<div>
    <a href="{{ get_the_ID() }}" class="btn cta">{{ $ctaBtn }}</a>
</div>
