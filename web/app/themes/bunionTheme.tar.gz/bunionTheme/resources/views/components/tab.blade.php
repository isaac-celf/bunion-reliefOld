<!-- Tab panes -->
<div class="tab-img-box">
    <img src="{{ $tabImage }}" alt="tab image 1" class="tab-img w-50">
</div>
<div class="tab-body">
    <h3>{{ $tabTitle }}</h3>
    <p>{{ $tabDescription }}</p>

    @dump($tabDescription)
</div>
