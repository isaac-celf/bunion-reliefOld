<div class="{{ $block->classes }}">
    <x-button ctaBtn="Find out more" />
</div>
