<div class="{{ $block->classes }} tabs">
    <InnerBlocks allowedBlocks='{{ $allowedBlocks }}' template='{{ $template }}' />
</div>
