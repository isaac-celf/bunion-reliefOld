self["webpackHotUpdate_roots_bud_sage_sage"]("app",{

/***/ "../node_modules/@roots/bud-support/lib/css-loader/index.cjs??css!../node_modules/postcss-loader/dist/cjs.js??postcss!../node_modules/resolve-url-loader/index.js??resolve-url!../node_modules/sass-loader/dist/cjs.js??sass!./styles/app.scss":
/***/ (() => {

throw new Error("Module build failed (from ../node_modules/sass-loader/dist/cjs.js):\nExpected \"n\".\n   ╷\n55 │         &:nth-child() .wp-block-group {\n   │                     ^\n   ╵\n  resources/styles/gutenburg/_section.scss 55:21  @import\n  resources/styles/gutenburg/main.scss 5:9        @import\n  resources/styles/app.scss 8:9                   root stylesheet");

/***/ })

});